import { MenuLink } from "./menulink"
export const GenderMenu =() =>{

    return(
    
        <ul className="nav justify-content-center">
          <MenuLink name="homme"/>
          <MenuLink name="femme"/>
        </ul>
      
    )
}