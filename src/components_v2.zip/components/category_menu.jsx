export const CategoryMenu =() =>{

    return(
    
        <ul className="nav justify-content-center">
          <li className="nav-item">
            <a className="nav-link" href="#">Pantalons</a>
          </li>
          <li className="nav-item">
            <a className="nav-link" href="#">T-shirts</a>
          </li>
          <li className="nav-item">
            <a className="nav-link" href="#">Pulls</a>
          </li>
          <li className="nav-item">
            <a className="nav-link" href="#">Chaussures</a>
          </li>
          <li className="nav-item">
            <a className="nav-link" href="#">Sous-vêtements</a>
          </li>
          <li className="nav-item">
            <a className="nav-link" href="#">Accessoires</a>
          </li>
        </ul>
      
    )
}